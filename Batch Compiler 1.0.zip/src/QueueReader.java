/**
 * 
 */
package rollercoaster;

import java.io.File;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author maellis1, loran
 * @version 10-13-2015
 * 
 *
 */

public class QueueReader  {

   
    /**
     * Constructor 
     * INstiates a CoasterWindow
     * as well as RollerCoasterQueue is created and WiitingParties are added to the queue
     * @param fileName
     */ 
    public QueueReader(String fileName) {
        new CoasterWindow(readQueueFile(fileName));
   
    }
    
    /**
     * readQueueFile
     * The file fileNAme is parsed and Waiting Parties are created 
     * as well as RollerCoasterQueue is created and WiitingParties are added to the queue
     * @param fileName
     */
    public RollerCoasterQueue readQueueFile(String fileName){
        RollerCoasterQueue bigLine = new RollerCoasterQueue();
        Scanner fileData = null;
        try {
            // Can throw FileNotFoundException
            fileData = new Scanner(new File(fileName));
        } catch (FileNotFoundException e) {
            System.out.println("Scanner error opening the file " + fileName);
            System.out.println(e.getMessage());

        }

        int cnt = 0;
        WaitingParty partyArriving = null;
        while (fileData.hasNextLine()) {
            // System.out.println("looping through file lines");
            String line = fileData.nextLine();
            if (cnt % 2 == 0) // the odd lines with booleans
            {

                if (line.contains("false")) {
                    partyArriving = new WaitingParty(false);
                } else
                    partyArriving = new WaitingParty(true);

            } else // lists of names which is the even lines
            {
                String[] lineArray = line.split(", *");
                for (int i = 0; i < lineArray.length; i += 2) {
                    String name = lineArray[i];
                    int height = Integer.valueOf(lineArray[i + 1]);
                    Person rider = new Person(name, height);
                    partyArriving.add(rider);
                }

                // System.out.println("lineArray");
                //for (int i = 0; i < lineArray.length; i++) {
                //    System.out.println(i + ": " + lineArray[i] + "\n");
                //}

                // System.out.println("That lineArray should get put into
                // partyArriving and then queued in bigLine");
                // System.out.println("partyArriving: " +
                // partyArriving.toString());
                bigLine.enqueueParty(partyArriving);

            }
            // System.out.println(line);
            cnt++;
        } // end while
        fileData.close();
        return bigLine;
        
    }
    
    
    
    /**
     * main method
     */
    public static void main(String[] args) {


        if (args.length == 1) {
            new QueueReader(args[0]);
        } else {
            new QueueReader("input.txt");
        }
     

    }

 
}
